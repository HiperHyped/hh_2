import 'package:flutter/material.dart';
import 'package:hh_2/src/config/ai/xerxes_operations.dart';
import 'package:hh_2/src/config/common/var/hh_colors.dart';
import 'package:hh_2/src/config/common/var/hh_globals.dart';
import 'package:hh_2/src/config/common/var/hh_notifiers.dart';
import 'package:hh_2/src/config/db/db_history.dart';
import 'package:hh_2/src/models/history_model.dart';
import 'package:hh_2/src/pages/basket/basket_bar.dart';
import 'package:hh_2/src/pages/hint/hint_bar.dart';
import 'package:hh_2/src/pages/history/history_bar.dart';
import 'package:hh_2/src/pages/pay/pay_bar.dart';
import 'package:hh_2/src/pages/prodpage/prod_page.dart';
import 'package:badges/badges.dart' as badges;




//BASESCREEN FUNCIONANDO 02/06
class BaseScreen extends StatefulWidget {
  final bool isVertical;

  const BaseScreen({Key? key, required this.isVertical}) : super(key: key);

  @override
  State<BaseScreen> createState() => _BaseScreenState();
}

class _BaseScreenState extends State<BaseScreen> {
  int currentIndex = 0;
  final totalPriceNotifier = ValueNotifier<double>(0.0);

  
  bool showBasketBar = false;
  bool showHintBar = false;
  bool showHistoryBar = false;
  bool showSettingBar = false;
  bool showPayBar = false;

  final DBHistory _dbHistory = DBHistory();
  
  @override
  void initState() {
    super.initState();
    loadHistoryOnce();

    //HHNotifiers.counter['basketItemCount']!.value = HHGlobals.HHBasket.value.productQuantities.length;
    //HHGlobals.HHBasket.value.products
    // IA: 2023-06-08 - Atualizar o contador de itens da cesta sempre que a cesta mudar.
    /// e APLICAR XERXES!!!!!!
    HHNotifiers.counter[CounterType.BasketCount]!.addListener(() async {
      if(HHGlobals.HHBasket.value.isNotEmpty) {
        print("NOTIFIERS: ${HHNotifiers.counter[CounterType.BasketCount]}");
        XerxesOperations operations = XerxesOperations();
        await operations.performOperations();
      }
    });
  }

  void loadHistoryOnce() async {
      HistoryModel history = await _dbHistory.getBasketHistory(HHGlobals.HHUser.userId);
      HHGlobals.HHUserHistory.value = history;
      HHNotifiers.counter[CounterType.HistoryCount]!.value = history.basketHistory.length;
    }

  @override
  void dispose() {
    HHGlobals.HHBasket.removeListener(() {});

    super.dispose();
  }
  

  Widget _buildBody(bool vertical, bool isLandscape) {
    return Stack(
      children: [
        Positioned.fill( //ou Container ----- havia um Expanded aqui e isso dava erro...
          child: ProdPage(isVertical: vertical),
        ),
        if (showBasketBar)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 100,
              child: BasketBar(totalPriceNotifier: totalPriceNotifier),
            ),
          ),
        if (showHintBar)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 200,
              child: HintBar(),
            ),
          ),
        if (showHistoryBar)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 100,
              child: HistoryBar(),
            ),
          ),
        if (showSettingBar)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 100,
              child: Container(),
            ),
          ),
        if (showPayBar)
          Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: 70,
                child: PayBar(totalPriceNotifier: totalPriceNotifier),
              ),
            ),
          /*Positioned(
            bottom: 0,
            right: 0,
            child: PayBar(totalPriceNotifier: totalPriceNotifier),
          ),*/
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: OrientationBuilder(
        builder: (context, orientation) {
          bool isLandscape = orientation == Orientation.landscape;
          return _buildBody(widget.isVertical, isLandscape);
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        showSelectedLabels: true,  // Os rótulos dos itens selecionados são exibidos
        showUnselectedLabels: false,  // Os rótulos dos itens não selecionados são ocultados
        currentIndex: currentIndex,
         onTap: (index) {
          setState(() {
            if (currentIndex == index) {
              // O usuário tocou no botão da barra atualmente visível.
              // Portanto, alternamos o estado visível da respectiva barra.
              switch (index) {
                case 0:
                  if (HHGlobals.HHBasket.value.isNotEmpty) showBasketBar = !showBasketBar;
                  break;
                case 1:
                  if (HHGlobals.HHSuggestionList.value.isNotEmpty) showHintBar = !showHintBar;
                  break;
                case 2:
                  if (HHGlobals.HHUserHistory.value.basketHistory.isNotEmpty) showHistoryBar = !showHistoryBar;
                  break;
                case 3:
                  showSettingBar = !showSettingBar;
                  break;
                case 4:
                  showPayBar = !showPayBar;
                  break;
                default:
                  break;
              }
            } else {
              // O usuário tocou em um botão diferente.
              // Portanto, ocultamos todas as barras e mostramos a barra correspondente.
              showBasketBar = false;
              showHintBar = false;
              showHistoryBar = false;
              showSettingBar = false;
              showPayBar = false;
              currentIndex = index;

              switch (index) {
                case 0:
                  if (HHGlobals.HHBasket.value.isNotEmpty) showBasketBar = true;
                  break;
                case 1:
                  if (HHGlobals.HHSuggestionList.value.isNotEmpty) showHintBar = true;
                  break;
                case 2:
                  if (HHGlobals.HHUserHistory.value.basketHistory.isNotEmpty) showHistoryBar = true;
                  break;
                case 3:
                  showSettingBar = true;
                  break;                
                case 4:
                  showPayBar = true;
                  break;
                default:
                  break;
              }
            }
          });
        },

        //Basket
        backgroundColor: HHColors.hhColorGreyMedium,
        elevation: 0,
        selectedItemColor: HHColors.hhColorFirst,
        unselectedItemColor: HHColors.hhColorGreyDark,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
            icon: ValueListenableBuilder<int>(
              valueListenable: HHNotifiers.counter[CounterType.BasketCount]!,
              builder: (context, count, _) => 
                badges.Badge(
                  badgeStyle: badges.BadgeStyle(padding:EdgeInsets.all(6.0)),
                  badgeContent: Text(
                    count.toString(),
                    style: TextStyle(color: Colors.white),
                    ),
                  position: badges.BadgePosition.topEnd(top: -5, end: -0),
                  showBadge: count >= 1 ? true : false,
                  child: const Icon(
                    size: 40,
                    Icons.shopping_cart_outlined
                    ),
                ),
              ),
            label: 'Carrinho',
          ),

          // Hint!
          BottomNavigationBarItem(
            icon: ValueListenableBuilder<int>(
              valueListenable: HHNotifiers.counter[CounterType.HintCount]!,
              builder: (context, count, _) => 
                badges.Badge(
                badgeStyle: badges.BadgeStyle(
                  badgeColor: HHColors.hhColorDarkFirst,
                  shape: badges.BadgeShape.circle,
                  padding: EdgeInsets.all(6.0),
                  //borderRadius: BorderRadius.circular(10),
                  ),
                badgeContent: Text(
                  count.toString(),
                  style: TextStyle(color: Colors.white),
                  ),
                position: badges.BadgePosition.topEnd(top: -5, end: -0),
                showBadge: count >= 1 ? true : false,
                child: const Icon(
                  size: 40,
                  Icons.lightbulb_outline
                  ),
                ),
              ),
            label: 'Receitas',
          ),
         
          // Historico
          BottomNavigationBarItem(
            icon: ValueListenableBuilder<int>(
              valueListenable: HHNotifiers.counter[CounterType.HistoryCount]!,
              builder: (context, count, _) => 
                badges.Badge(
                  badgeStyle: const badges.BadgeStyle(
                    badgeColor: Colors.purple,
                    shape: badges.BadgeShape.circle,
                    padding: EdgeInsets.all(6.0),
                  ),
                  badgeContent: Text(
                    count.toString(),
                    style: TextStyle(color: Colors.white),
                  ),
                  position: badges.BadgePosition.topEnd(top: -5, end: -0),
                  showBadge: count >= 1 ? true : false,
                  child: const Icon(
                    size: 40,
                    Icons.history
                  ),
                ),
              ),
            label: 'Histórico',
          ),

          // Preferências
          const BottomNavigationBarItem(
            icon: Icon(size: 40, Icons.settings_outlined), // ícone de pagamento
            label: 'Preferências',
          ),

          // Pagamento
          const BottomNavigationBarItem(
            icon: Icon(size: 40,Icons.payment), // ícone de pagamento
            label: 'Pagamento',
          ),
        ],
      ),
    );
  }
}




