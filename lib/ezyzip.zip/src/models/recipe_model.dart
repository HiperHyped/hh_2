import 'package:hh_2/src/models/ean_model.dart';

class RecipeModel {
  String recipeName = '';
  List<EanModel> ingredients = [];
  List<String> description = [];

  RecipeModel({this.recipeName = '', this.ingredients = const [], this.description = const []});



  @override
  String toString() {
    return 'RecipeModel{'
      'recipe: $recipeName, '
      'ingredients: ${_listToString(ingredients)}, '
      'description: ${_listToString(description)}, '
    '}';
  }

  String _listToString(List list) {
    return list.map((item) => item.toString()).join(', ');
  }
}