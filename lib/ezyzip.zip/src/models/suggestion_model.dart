import 'package:hh_2/src/config/db/db_search.dart';
import 'package:hh_2/src/models/ean_model.dart';
import 'package:hh_2/src/models/recipe_model.dart';
import 'package:hh_2/src/models/search_model.dart';

class SuggestionModel {
  int suggest_id = 0;
  String recipe = '';
  List<EanModel> initialProductList = []; //String
  List<String> suggestProductList = [];
  List<String> totalProductList = [];
  List<SearchModel> searchProductList = [];
  List<EanModel> dbSearchResultList = [];  
  final DBSearch _dbSearch = DBSearch(); 
  RecipeModel recipeModel = RecipeModel();
  int? userFeedback;
  int? cartLastPressed;

  SuggestionModel({this.recipe = '', this.suggestProductList = const []});


  // Método que transforma a productList em uma lista de SearchModel
  void toSearchModelList() {
    searchProductList = suggestProductList.map((product) {
      return SearchModel(
        searchType: "product",  
        nome: product,
      );
    }).toList();
  }

  // Método para criar a lista totalProductList
  /*void createTotalProductList(List<String> products) {
    totalProductList = List<String>.from(basketProductList);
  }*/

  void createTotalProductList() {
    //totalProductList = [...initialProductList, ...suggestProductList];
    totalProductList = [...initialProductList.map((product) => product.nome), ...suggestProductList];
  }

  // Método que realiza a pesquisa no banco de dados para cada item em searchProductList
  Future<void> generateDBSearchResults() async {
    for (var searchProduct in searchProductList) {
      print("SEARCHPRODUCT:  ${searchProduct.searchType} ==> ${searchProduct.nome}");
      var searchResult = await _dbSearch.searchProductV2(searchProduct, 1);  //somente a 1a resposta
      dbSearchResultList.addAll(searchResult);
    }
  }


  @override
  String toString() {
    return 'SuggestionModel{'
      'recipe: $recipe, '
      'initialProductList: ${initialProductList.map((product) => product.nome).join(', ')}, '
      'suggestProductList: $suggestProductList, '
      'totalProductList: $totalProductList, '
      //'searchProductList: ${_listToString(searchProductList)}, '
      'dbSearchResultList: ${dbSearchResultList.map((product) => product.nome).join(', ')}, '
      'dbSearch: $_dbSearch, '
      'recipeModel: $recipeModel'
    '}';
  }

  String _listToString(List list) {
    return list.map((item) => item.toString()).join(', ');
  }
}


  


