//DAQUI A POUCO... DEPRECATED

class CategoryModel{
  String cat0;
  String cat1;
  String cat2;
  String nmcat;
  String sig0;
  String sig1;
  String sig2;
  String sigla;

  CategoryModel(
    this.cat0,
    this.cat1,
    this.cat2,
    this.nmcat,
    this.sig0,
    this.sig1,
    this.sig2,
    this.sigla,
  );

}


class Cat0{
  String cat0;
  String sig0;
  List<Cat1> cat1;

  Cat0(
    this.cat0,
    this.sig0,
    this.cat1,
  );


}

class Cat1{
  String cat1;
  String sig1;
  List<Cat2> cat2;

  Cat1(
    this.cat1,
    this.sig1,
    this.cat2
  );

}

class Cat2{
  String cat2;
  String sig2;
  String sigla;
  String nmcat;

  Cat2(
    this.cat2,
    this.sig2,
    this.sigla,
    this.nmcat,
  );
}