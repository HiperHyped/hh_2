//NOT USED
class StockModel{
  String uf;
  int quantity; 

  StockModel(
    this.uf,
    this.quantity,
  );

}