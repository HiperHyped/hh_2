import 'package:flutter/material.dart';
import 'package:xml/xml.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;


//Versão 2
// IA 13-05 - Adicione um campo 'isExpanded' para controlar a visibilidade das subcategorias.
class CatModel {
  final String nom;
  final String sig;
  final String emj;
  final int ord;
  final Color color;
  final String? sigla;
  final List<CatModel> subCats;
  final int level;
  bool isExpanded; // IA 13-05

  CatModel({
    required this.nom,
    required this.sig,
    required this.emj,
    required this.ord,
    required this.color,
    required this.subCats,
    required this.level,
    this.sigla,
    this.isExpanded = true, // IA 13-05 - Defina 'isExpanded' como verdadeiro por padrão.
  });

}


//Versão 1
/*class Cat {
  final String nom;
  final String sig;
  final String emj;
  final int ord;
  final Color color;
  final String? sigla; // novo campo opcional
  final List<Cat> subCats;
  final int level; // novo campo para identificar o nível

  Cat({
    required this.nom, 
    required  this.sig, 
    required this.emj, 
    required this.ord, 
    required this.color, 
    required this.subCats, 
    required this.level, 
    required this.sigla
  });

  factory Cat.fromXml(XmlElement xmlElement, int level) {
    String cor = xmlElement.findElements('COR').single.text;
    Color color = Color(int.parse(cor.substring(1, 7), radix: 16) + 0xFF000000);

    return Cat(
      nom: xmlElement.findElements('NOM${level.toString()}').single.text,
      sig: xmlElement.findElements('SIG${level.toString()}').single.text,
      emj: xmlElement.findElements('EMJ${level.toString()}').single.text,
      ord: int.parse(xmlElement.findElements('ORD${level.toString()}').single.text),
      color: color,
      sigla: level == 2 ? xmlElement.findElements('SIGLA').single.text : null,
      subCats: xmlElement.findElements('CATS${(level + 1).toString()}').isEmpty 
        ? [] 
        : xmlElement.findElements('CATS${(level + 1).toString()}').
            single.findElements('CAT${(level + 1).toString()}').
                map((item) => Cat.fromXml(item, level + 1)).toList(),
      level: level,
    );
  }
}

class CatRoot {
  List<Cat> cats;

  CatRoot({required this.cats});

  factory CatRoot.fromXml(XmlElement xmlElement) {
    return CatRoot(
      cats: xmlElement.findElements('CAT0').map((item) => Cat.fromXml(item, 0)).toList(),
    );
  }
}*/


/*
  factory Cat.fromXml(XmlElement xmlElement, int level) {
    String cor = xmlElement.findElements('COR$level').single.text;
    Color color = Color(int.parse(cor.substring(1, 7), radix: 16) + 0xFF000000);

    return Cat(
      nom: xmlElement.findElements('NOM$level').single.text,
      sig: xmlElement.findElements('SIG$level').single.text,
      emj: xmlElement.findElements('EMJ$level').single.text,
      ord: int.parse(xmlElement.findElements('ORD$level').single.text),
      color: color,
      sigla: level == 2 ? xmlElement.findElements('SIGLA').single.text : null,
      subCats: level < 2 && !xmlElement.findElements('CATS${level + 1}').isEmpty
          ? xmlElement
              .findElements('CATS${level + 1}')
              .single
              .findElements('CAT${level + 1}')
              .map((item) => Cat.fromXml(item, level + 1))
              .toList()
          : [],
      level: level,
    );
  }
}

class CatRoot {
  final List<Cat> cats;

  CatRoot({required this.cats});

  factory CatRoot.fromXml(XmlElement xmlElement) {
    return CatRoot(
      cats: xmlElement.findElements('CAT0').map((item) => Cat.fromXml(item, 0)).toList(),
    );
  }

  static Future<CatRoot> fromUrl(String url) async {
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final document = XmlDocument.parse(utf8.decode(response.bodyBytes));
      return CatRoot.fromXml(document.findElements('CATS').single);
    } else {
      throw Exception('Failed to load XML data');
    }
  }
}
*/