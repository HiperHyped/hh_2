import 'package:flutter/material.dart';
import 'package:hh_2/src/config/common/var/hh_notifiers.dart';
import 'package:hh_2/src/config/db/db_basket.dart';
import 'package:hh_2/src/config/db/db_service.dart';
import 'package:hh_2/src/models/ean_model.dart';


enum SourceStatus {
  grid,
  history,
  hint,
  // add more as necessary
}

enum HintStatus {
  xerxes,
  notXerxes,
  hint,
  // add more as necessary
}

class EanInfo {
  final SourceStatus sourceStatus;
  final HintStatus hintStatus;

  EanInfo({required this.sourceStatus, required this.hintStatus});
}


class BasketModel {
  List<EanModel> products = [];
  Map<EanModel, int> productQuantities = {};
  Map<EanModel, EanInfo> productInfo = {};
  Function(double)? _onBasketChanged;
  ValueNotifier<double> totalPriceNotifier = ValueNotifier<double>(0);
  int basket_id = 0;
  int user_id = 0;
  int? cartLastPressed;
  DateTime? basketTime;

  // Adicione uma instância de DBBasket
  final DBBasket _dbBasket = DBBasket(DBService());

  BasketModel();

  bool containsProduct(EanModel prodContains) {

    for (EanModel product in products){
      if(product.ean == prodContains.ean) return true;
    }
    return false;
    //return products.contains(product);
  }

  EanInfo getProductInfo(EanModel product) {
    return productInfo[product]!;
  }

  bool get isNotEmpty {
    return products.isNotEmpty;
  }


  /// CLEAR BASKET
  void clearBasket() async {
    products.clear();
    // Chamando função de DBBasket
    print("CLEAR BASKET");
    await _dbBasket.clearBasket(basket_id);
    _updateTotalPrice();
    groupProducts();
  }

  //ADD PRODUCT v2
  void addProduct(EanModel product) async {
    containsProduct(product)? 
      products.add(product):
      products.insert(0, product); // Adicione o produto no início da lista
    // Chamando função de DBBasket
    print("ADD PRODUCT v2");
    await _dbBasket.addProduct(product, basket_id);
    if (_onBasketChanged != null) {
      _onBasketChanged!(totalPrice());
      
    }
    _updateTotalPrice();
    groupProducts();
    _updateBasketCount();
  } 

  // Adiciona uma lista de produtos EanModel
  void addProductList(List<EanModel> productList) async {
    for (EanModel product in productList) {
      print(product.toString());
      addProduct(product); // Chamamos a função addProduct já existente para adicionar cada produto
    }
  }

  //REMOVE PRODUCT v2
  void removeProduct(EanModel product) async {
    int lastIndex = products.lastIndexOf(product);
    if (lastIndex != -1) {
      products.removeAt(lastIndex);
      // Chamando função de DBBasket
      print("REMOVE PRODUCT v2");
      await _dbBasket.removeProduct(product, basket_id);
      if (_onBasketChanged != null) {
        _onBasketChanged!(totalPrice());
      }
      _updateTotalPrice();
      groupProducts();
      _updateBasketCount();
    }
  }


  //GROUP PRODUCTS

  //v1
  Map<EanModel, int> groupProducts() {
    productQuantities = {};
    for (EanModel product in products) {
      int index = productQuantities.keys.toList().indexWhere((item) => item.ean == product.ean);
      if (index != -1) {
        EanModel existingProduct = productQuantities.keys.toList()[index];
        productQuantities[existingProduct] = productQuantities[existingProduct]! + 1;
      } else {
        productQuantities[product] = 1;
      }
    }
    //HHNotifiers.counter[CounterType.BasketCount]!.value = productQuantities.length;
    return productQuantities;
  }


  /*Map<EanModel, int> groupProducts() {
    Map<EanModel, int> productCountMap = {};
    //print("PRODUCTS: $products");
    for (EanModel product in products) {
      if (productCountMap.containsKey(product)) {
        productCountMap[product] = productCountMap[product]! + 1;
      } else {
        productCountMap[product] = 1;
      }
    }
    //print("GROUPPRODUCTS: $productCountMap");
    return productCountMap;
  }*/

  ///REMOVE ALL OF A PRODUCT FROM BASKET
  void removeAllOfProduct(EanModel product) async {
    products.removeWhere((element) => element == product);
    // Chamando função de DBBasket
    print("REMOVE ALL OF A  PRODUCT");
    await _dbBasket.removeAllOfAProduct(product, basket_id);
    if (_onBasketChanged != null) {
      _onBasketChanged!(totalPrice());
    }
    _updateTotalPrice();
    groupProducts();
    _updateBasketCount();
  }

    // Adiciona uma lista de produtos EanModel
  void removeAllOfProductList(List<EanModel> productList) async {
    for (EanModel product in productList) {
      removeAllOfProduct(product); // Chamamos a função addProduct já existente para adicionar cada produto
    }
  }

  /// CALCUL OF TOTAL PRICE
  double totalPrice() {
    double total = 0;
    Map<EanModel, int> productCountMap = groupProducts();
    for (EanModel product in productCountMap.keys) {
      int count = productCountMap[product]!;
      total += double.parse(product.preco) * count;
    }
    print("TOTAL: $total");
    return total;
  }

  void _updateTotalPrice() {
    totalPriceNotifier.value = totalPrice();
  }

  void _updateBasketCount() {
    HHNotifiers.counter[CounterType.BasketCount]!.value = productQuantities.length;
  }

  void setOnBasketChangedCallback(Function(double) callback) {
    _onBasketChanged = callback;
  }
}


/*
class BasketModel {
  List<EanModel> products = [];
  Function(double)? _onBasketChanged;
  ValueNotifier<double> totalPriceNotifier = ValueNotifier<double>(0);
  int basket_id = 0;
  int user_id = 0;


  bool containsProduct(EanModel product) {
    return products.contains(product);
  }

  bool get isNotEmpty {
    return products.isNotEmpty;
  }

  /// CLEAR BASKET
  void clearBasket() {
    products.clear();
    _updateTotalPrice();
  }

  //ADD PRODUCT v2
  void addProduct(EanModel product) {
    containsProduct(product)? 
      products.add(product):
      products.insert(0, product); // Adicione o produto no início da lista
    if (_onBasketChanged != null) {
      _onBasketChanged!(totalPrice());
      
    }
    _updateTotalPrice();
  } /////// NOVO: fila para a esquerda



  //REMOVE PRODUCT v2
  void removeProduct(EanModel product) {
  int lastIndex = products.lastIndexOf(product);
  if (lastIndex != -1) {
    products.removeAt(lastIndex);
    if (_onBasketChanged != null) {
      _onBasketChanged!(totalPrice());
    }
    _updateTotalPrice();
    }
  }

  //GROUP PRODUCTS
  Map<EanModel, int> groupProducts() {
    Map<EanModel, int> productCountMap = {};
    for (EanModel product in products) {
      if (productCountMap.containsKey(product)) {
        productCountMap[product] = productCountMap[product]! + 1;
      } else {
        productCountMap[product] = 1;
      }
    }
    return productCountMap;
  }


  ///REMOVE ALL OF A PRODUCT FROM BASKET
  void removeAllOfProduct(EanModel product) {
    products.removeWhere((element) => element == product);
    if (_onBasketChanged != null) {
      _onBasketChanged!(totalPrice());
    }
  }

  /// CALCUL OF TOTAL PRICE
  double totalPrice() {
    double total = 0;
    Map<EanModel, int> productCountMap = groupProducts();
    for (EanModel product in productCountMap.keys) {
      int count = productCountMap[product]!;
      total += double.parse(product.preco) * count;
    }
    print("TOTAL: $total");
    return total;
  }

   void _updateTotalPrice() {
    totalPriceNotifier.value = totalPrice();
  }

  void setOnBasketChangedCallback(Function(double) callback) {
    _onBasketChanged = callback;
}

}*/
