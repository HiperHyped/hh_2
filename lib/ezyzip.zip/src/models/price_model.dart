
// DEPRECATED
class PriceModel{
  
  String ean;
  String price;
  String uf;
  String atual;

  PriceModel( 
    {
    this.ean = "",
    this.price = "",
    this.uf = "",
    this.atual = "",
    }
  );
  
}