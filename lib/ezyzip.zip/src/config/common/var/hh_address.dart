import 'package:flutter/material.dart';
import 'package:hh_2/src/config/xml/xml_data.dart';
import 'package:hh_2/src/models/ean_model.dart';
import 'package:hh_2/src/models/category_model.dart';

abstract class HHAddress {

  static String urlS3 = "https://hiperhypedbucket.s3.sa-east-1.amazonaws.com/";

  static String urlDb = "${urlS3}db/";

  static String urlCat = "${urlS3}cat/";

  static String urlXml = "${urlS3}xml/";

}

////SENHAS
