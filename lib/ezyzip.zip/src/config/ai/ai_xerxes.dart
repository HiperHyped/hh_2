
import 'package:dart_openai/openai.dart';
import 'package:hh_2/src/config/ai/ai_service.dart';
import 'package:hh_2/src/models/ean_model.dart';
import 'package:hh_2/src/models/recipe_model.dart';
import 'package:hh_2/src/models/suggestion_model.dart';

class Xerxes {
  late final AIService _aiService;
  String model =  "gpt-3.5-turbo"; //gpt-3.5-turbo-16k-0613 //gpt-3.5-turbo //"gpt-4" ;

  Xerxes() {
    _aiService = AIService();  // Inicializando _aiService no construtor
  }

  /////////////
  ///  X1  ////
  /////////////
  //Future<SuggestionModel> x1(List<String> products) async {
  /*Future<SuggestionModel> x1(List<String> products, {void Function()? onCompleted}) async {
    var productsStr = products.join(', ');*/

  Future<SuggestionModel> x1(List<EanModel> products, {void Function()? onCompleted}) async {

    var productsStr = products.map((product) => product.nome).join(', ');

    var systemMessage = 
      """
      Você funcionará como um API para supermercado chamado X1. 
      Com base nos produtos listados, você deverá fornecer o nome de uma receita sugerida e uma lista com o nome dos ingredientes adicionais necessários sugeridos. 
      O nome da receita será utilizado por um outro API. A lista de produtos será utilizada em outro API.
      Dessa forma, é EXTREMAMENTE importante que você responda EXATAMENTE da mesma maneira que os exemplos abaixos:
      Exemplo 1: "X1 Feijão Preto, Linguiça, Coca Cola". Resposta: '{Sugestão: {Feijoada}, Lista: {Arroz, Bacon, Paio, Couve mineira, Laranja, Pimenta}}'
      Exemplo 2: "X1 Leite, Farinha, Chocolate, Peixe". Resposta: '{Sugestão: {Bolo de Chocolate}, Lista: {Fermento, Ovos, Açúcar, Chocolate em barras}}'
      IMPORTANTE: Se um dos produtos não tiver ligação com os outros em uma possível receita, simplesmente ignore aquele produto específico, como Coca Cola e Peixe nos exemplos.
      Tente sempre achar uma boa sugestão! Se não tiver sugestão, somente responda com valores vazios, dessa forma: {Sugestão: [], Lista: []}
      """;

    var userMessage = "X1 $productsStr";

    
    var messages = [
      OpenAIChatCompletionChoiceMessageModel(
        content: systemMessage,
        role: OpenAIChatMessageRole.system,
      ),
      OpenAIChatCompletionChoiceMessageModel(
        content: userMessage,
        role: OpenAIChatMessageRole.user,
      ),
    ];

    var chatCompletion = await _aiService.createChat(
      model: model,
      messages: messages,
    );

    SuggestionModel suggestion = SuggestionModel();
    //suggestion.initialProductList = products;
    //suggestion.initialProductList = products.map((product) => product.nome).toList();
    // Copiamos a lista de produtos para initialProductList em vez de mapeá-la para seus nomes
    suggestion.initialProductList = List.from(products);
    suggestion = await handleX1Response(chatCompletion.choices[0].message.content, suggestion);
    suggestion.createTotalProductList();

    print(
      """
      "X1 ---> RECEITA: ${suggestion.recipe},\n 
      PRODUCTS: $products, \n
      LISTA INITIAL:  ${suggestion.initialProductList.map((product) => product.nome).join(', ')},\n
      LISTA SUGEEST: ${suggestion.suggestProductList},\n
      LISTA TOTAL: ${suggestion.totalProductList},\n
      """);  // Imprima a recomendação. Voce pode fazer algo mais com isso, se quiser
    
    print("X1 TERMINADO");
    suggestion.toString();

    if (onCompleted != null) onCompleted();
    return suggestion;
    
  }

  /////////////////////////
  // Método para lidar com a resposta do X1 e transformá-la em uma instância de SuggestionModel
  Future<SuggestionModel> handleX1Response(String response, SuggestionModel suggestion) async {
    
    //SuggestionModel suggestion = SuggestionModel();
    final suggestionPattern = RegExp(r'Sugestão: {(.*?)}');
    final listPattern = RegExp(r'Lista: {(.*?)}');

    final suggestionMatch = suggestionPattern.firstMatch(response);
    final listMatch = listPattern.firstMatch(response);

    if (suggestionMatch == null || listMatch == null) {
      // Trata erro de formatação na resposta
      // ...
      return suggestion;
    }

    suggestion.recipe = suggestionMatch.group(1)!.trim();
    suggestion.suggestProductList = listMatch.group(1)!
        .split(',')
        .map((ingredient) => ingredient.trim())
        .toList();

    // Se a sugestão ou a lista de ingredientes forem strings vazias, substitua-as por valores padrão
    if (suggestion.recipe == '[]') suggestion.recipe = '';
    if (suggestion.suggestProductList.length == 1 && suggestion.suggestProductList[0] == '[]') suggestion.suggestProductList = [];

    suggestion.toSearchModelList();

    for (var searchModel in suggestion.searchProductList) {
      print(searchModel.toString());
      String s = await ax3_2(searchModel.nome); // ax3_1 é por cat2 - 1100 tokens;  ax3_2 é por cat0 - 300 tokens
      searchModel.sigla = s;  // Atualiza a sigla
      searchModel.searchType = 'prod_cat';
      print("AX3: ${searchModel.nome} ==> $s");
    }

    await suggestion.generateDBSearchResults();

    return suggestion;
  }

  /////////////
  ///  X2  ////
  /////////////
  //Future<RecipeModel> x2(SuggestionModel suggestion) async {
  Future<RecipeModel> x2(SuggestionModel suggestion, {void Function()? onCompleted}) async {

    
    var systemMessage = 
      """
      Você funcionará como um API para supermercado chamado X2. 
      Com base no nome da receita e na lista de ingredientes, você deverá fornecer um passo-a-passo em tópicos para preparar uma receita conhecida e consagrada.
      O resultado será utilizado por um outro API. 
      Dessa forma, é EXTREMAMENTE importante que você responda EXATAMENTE no seguinte formato (Uma Lista de Strings): 
      ["Passo 1: descrição do passo 1", Passo 2: descrição do passo 2, ...]
      Exemplo: Para a receita 'Feijoada' e a lista de ingredientes "Feijão Preto, Linguiça, Arroz, Bacon, Paio, Couve mineira, Laranja, Pimenta", a resposta deve ser:
      ["Passo 1: Coloque o feijão preto de molho por 12 horas", "Passo 2: Frite a linguiça e o bacon", ...]
      Se não tiver sugestão, somente responda com valor vazio, dessa forma: []
      Forneça a recieta mais relevante com a lista de produtos.
      """;

    //IMPORTANTE 2: Nem sempre uma lista de produtos formará uma boa receita ou uma receita válida. Não responda com uma receita se não tiver certeza de seu interesse e verossimilhança.
    //IMPORTANTE 1: Ignore produtos que não tenham a ver com a receita sugerida.

    /*for(var prod in suggestion.totalProductList){
      print("NOME PROD: ${prod}");
    }*/
    


    var userMessage = "RECEITA: ${suggestion.recipe}, INGREDIENTES: ${suggestion.totalProductList.map((e) => e).join(', ')}";
    print("X2 - UserMessage: $userMessage");
    var messages = [
      OpenAIChatCompletionChoiceMessageModel(
        content: systemMessage,
        role: OpenAIChatMessageRole.system,
      ),
      OpenAIChatCompletionChoiceMessageModel(
        content: userMessage,
        role: OpenAIChatMessageRole.user,
      ),
    ];

    var chatCompletion = await _aiService.createChat(
      model: model,
      messages: messages,
    );

    //print("X2 RESPOSTA: ${chatCompletion.choices[0].message.content}");

    // Atribui a descrição à RecipeModel
    RecipeModel recipeModel = RecipeModel();
    recipeModel.recipeName = suggestion.recipe;
    recipeModel.ingredients = suggestion.dbSearchResultList;
    recipeModel.description = handleX2Response(chatCompletion.choices[0].message.content);
    print('X2 ---> RECEITA: ${recipeModel.recipeName}');
      for (var passo in recipeModel.description) {
          print("PASSO: $passo");
      }
    print("X2 TERMINADO");

    if (onCompleted != null) onCompleted();
    return recipeModel;
  } 

  //////////////////////
  List<String> handleX2Response(String response) {
    final descriptionPattern = RegExp(r'"(Passo \d+:.*?)"', dotAll: true);
    //final descriptionPattern = RegExp(r'Passo (\d+:.*?)', dotAll: true);
    //final descriptionPattern = RegExp(r'Passo (\d+:.*?)(?= Passo|$)', dotAll: true);
    var matches = descriptionPattern.allMatches(response);
    //List<String> description = matches.map((match) => match.group(1)!).replaceFirst("Passo ", "")).toList(); 
    List<String> description = matches.map((match) => match.group(1)!.replaceFirst("Passo ", "")).toList(); 
    return description;
  }



  /////////////
  /// ax2_1 ///
  /////////////
  Future<bool> ax2_1(String receita, List<String> listaReceitas) async {

    // Se a lista de receitas estiver vazia, retorne false imediatamente
    if (listaReceitas.isEmpty) {
      return false;
    }

    String receitas = listaReceitas.join(', ');

    var systemMessage = 
      """
      Vou lhe dar uma receita. Quero que voce me diga se existe alguma receita muito parecida ou semanticamente igual em uma lista de receitas. 
      Responda somente 1 para dizer que existe ou 0 para dizer que não existe. Mesmo em línguas diferentes.
      Exemplo 1: RECEITA: "Risoto de Camarão", LISTA RECEITAS: ["Risoto Camarão"] ==> Resposta: 1
      Exemplo 2: RECEITA: "Bolo de Cenoura", LISTA RECEITAS: ["Bolo de Chocolate, Bolo de Laranja"] ==> Resposta: 0
      Exemplo 3: RECEITA:  Hot Dog, LISTA RECEITAS: [Hambúrguer, Cachorro Quente] ==> Resposta: 1
      Exemplo 4: RECEITA: Lasanha à Bolonhesa, LISTA RECEITAS:[Espaguete à Bolonhesa, Lasanha ao Molho Branco] ==> Resposta: 0
      Exemplo 4: RECEITA: Macarrão à Bolonhesa, LISTA RECEITAS:[Espaguete à Bolonhesa] ==> Resposta: 1
      """;

    var userMessage = 
      """
      A Receita $receita é igual ou muito parecida a qualquer uma das Receitas a seguir? $receitas. 1 é Sim e 0 é não
      Responda EXCLUSIVAMENTE E TÃO SOMENTE: 1 ou 0
      """;

    var messages = [
      OpenAIChatCompletionChoiceMessageModel(
        content: systemMessage,
        role: OpenAIChatMessageRole.system,
      ),
      OpenAIChatCompletionChoiceMessageModel(
        content: userMessage,
        role: OpenAIChatMessageRole.user,
      ),
    ];

    var chatCompletion = await _aiService.createChat(
      model: model,
      messages: messages,
    );

    print("Tokens: ${chatCompletion.usage.totalTokens}");
    // Assume-se que a resposta será '1' para verdadeiro e '0' para falso.
    return chatCompletion.choices[0].message.content.trim() == '1';
  }


  /////////////
  /// ax3_1 ///
  /////////////
  Future<String> ax3_1(String produto) async {
    var systemMessage = 
      """
      Esse é um API que categoriza produtos em categorias de Supermercado segundo a tabela abaixo: 
      sig0;cat0;sig1;cat1;cat2s
      B;Bebidas;BA;Adega;Cerveja Garrafa (BBACG) , Cerveja Lata (BBACL) , Destilados (BBADE) , Vinhos (BBAVI)
      B;Bebidas;BE;Bebidas;Água de Coco (BBEAC) , Água (BBEAG) , Energéticos (BBEEN) , Lácteos (BBELA) , Refrigerante (BBERE) , Sucos (BBESU)
      E;Estocáveis;BA;Básicos;Açúcares (EBAAC) , Matinais (EBACA) , Básicos (EBACE) , Massas (EBAMA) , Óleos (EBAOL)
      E;Estocáveis;DO;Doces;Biscoitos (EDOBI) , Bomboniere (EDOBO) , Mel e Geleias (EDOME) , Sobremesa (EDOSB)
      E;Estocáveis;ME;Mercearia;Conservas (EMECO) , Fórmulas (EMEFO) , Leite Condensado (EMELE) , Refresco Em Pó (EMERE) , Salgadinhos (EMESA) , Suplementos (EMESU)
      E;Estocáveis;PA;Padaria;Misturas (EPAMI) , Pães (EPAPA)
      E;Estocáveis;PR;Preparos;Molhos (EPRMO) , Sopas (EPRSO) , Temperos (EPRTE)
      H;Hortifruti;FL;In Natura;Frutas (HFLFR) , Legumes (HFLLE) , Verduras (HFLVE)
      H;Hortifruti;MI;Mix;Flores (HMIFL) , Mix (HMIMI) , Ovos (HMIOV)
      L;Limpeza;HI;Higiene;Absorventes (LHIAB) , Bucal (LHIBU) , Fraldas (LHIFR) , Papel Higiênico (LHIPA)
      L;Limpeza;LI;Limpeza;Limpeza de Cozinha (LLICO) , Lavanderia para Roupas (LLILA) , Limpeza Geral (LLILI)
      L;Limpeza;PE;Perfumaria;Barba (LPEBA) , Cabelo (LPECA) , Corpo (LPECO)
      L;Limpeza;SA;Saúde;Acessórios (LSAAC) , Remédios (LSARE) , Vitaminas (LSAVI)
      P;Perecíveis;AC;Acougue (Carnes Resfriadas);Aves (PACAV) , Carnes (PACCA)
      P;Perecíveis;CG;Congelados;Bovino (PCGBO) , Frango (PCGFR) , Petiscos (PCGPE) , Polpas (PCGPO) , Preparados (PCGPR) , Pescados (PCGPX) , Sorvetes (PCGSO) , Suino (PCGSU) , Vegetais (PCGVE)
      P;Perecíveis;FR;Frios;Linguiças e Presuntos (PFREM) , Iogurtes (PFRIO) , Manteigas (PFRMA) , Queijos (PFRQU)
      U;Utilitários;CA;Acessórios;Banheiro (UCABA) , Brinquedos (UCABR) , Decoracao (UCADE) , Papelaria (UCAPA) , Tecnologia (UCATE)
      U;Utilitários;CO;Cozinha;Copos (UCOCO) , Descartáveis (UCODE) , Eletroportáteis (UCOEL) , Louças (UCOLO) , Panelas (UCOPA) , Talheres (UCOTA) , Utensílios (UCOUT)
      U;Utilitários;MO;Moda;Calçados (UMOCA), Roupas (UMORO), Uniformes (UMOUN)
      U;Utilitários;PT;Pet Shop;Rações (UPTAL) , Brinquedos (UPTBR) , Higiene (UPTHI)
      U;Utilitários;VE;Veículos;Aditivos (UVEAD) , Limpeza (UVELI), Óleos (UVEOL)

      Vou lhe dar um produto e sua resposta deverá ser SOMENTE e EXCLUSIVAMENTE: A sigla de 5 letras entre parenteses correspondente na tabela.
      Exemplo: Arroz. Resposta: EBACE
      Exemplo: Alho. Resposta: HFLLE
      Exemplo: Sal. Resposta: EPRTE
      Exemplo: oleo de oliva. Resposta: EBAOL
      """;

      var userMessage = "ax3_1 Produto: $produto. Responda SOMENTE e EXCLUSIVAMENTE: A sigla de 5 letras entre parenteses correspondente na tabela.";

      var messages = [
        OpenAIChatCompletionChoiceMessageModel(
          content: systemMessage,
          role: OpenAIChatMessageRole.system,
        ),
        OpenAIChatCompletionChoiceMessageModel(
          content: userMessage,
          role: OpenAIChatMessageRole.user,
        ),
      ];

      var chatCompletion = await _aiService.createChat(
        model: model,
        messages: messages,
      );

      print("Tokens:" + chatCompletion.usage.totalTokens.toString());
      return chatCompletion.choices[0].message.content.trim();
    }


  /////////////
  /// ax3_2 ///
  /////////////
  Future<String> ax3_2(String produto) async {
    var systemMessage = 
        """
        Esse é um API que categoriza produtos em 6 categorias de Supermercado: 
        H (Hortifruti), B (Bebidas), E (Estocáveis), P (Perecíveis),  L (Limpeza), U (Utensílios).
        Vou lhe dar um produto e sua resposta deverá ser SOMENTE e EXCLUSIVAMENTE uma dessas seis letras: B,E,P,H,L,U.
        Exemplos:
        B (Bebidas: líquidos como água, refrigerantes, bebidas alcoólicas, sucos),
        E (Estocáveis: pós, grãos como arroz, feijão, cereais, pães, conservas, biscoitos, chocolates, bombons, doces),
        P (Perecíveis: carnes, congelados, frios, embutidos, queijos, polpas),
        H (Hortifruti: ovos, frutas, verduras, legumes, raízes, tubérculos in natura ou minimamente processados),
        L (Limpeza: produtos de limpeza e higiene para casa, corpo, cabelo, roupas),
        U (Utensílios: bens duráveis vendidos em supermercado).
        Responda SOMENTE e EXCLUSIVAMENTE com uma única letra: B,E,P,H,L,U.
         """ ;

      var userMessage = "ax3_1 Produto: $produto. Responda SOMENTE e EXCLUSIVAMENTEcom uma única letra: B,E,P,H,L,U";

      var messages = [
        OpenAIChatCompletionChoiceMessageModel(
          content: systemMessage,
          role: OpenAIChatMessageRole.system,
        ),
        OpenAIChatCompletionChoiceMessageModel(
          content: userMessage,
          role: OpenAIChatMessageRole.user,
        ),
      ];

      var chatCompletion = await _aiService.createChat(
        model: model,
        messages: messages,
      );

      print("Tokens:" + chatCompletion.usage.totalTokens.toString());
      return chatCompletion.choices[0].message.content.trim();
    }



  }




  /*
  List<String> handleX2Response(String response) {
    final descriptionPattern = RegExp(r'Passo \d+: .*?(?={|$)');
    var matches = descriptionPattern.allMatches(response);
    List<String> description = matches.map((match) => match.group(0)!.replaceFirst('{', '').replaceFirst('}', '').trim()).toList(); 
    return description;
  }*/

  /*List<String> handleX2Response(String response) {
    final descriptionPattern = RegExp(r'(Passo \d+: {.*?})');
    var matches = descriptionPattern.allMatches(response);
    print("MATCHES: $matches");
    List<String> description = matches.map((match) => match.group(0)!.trim()).toList(); 
    return description;
  }*/

    // Aqui você precisará de uma função para parsear a resposta do GPT-3.5-turbo e transformá-la em uma lista de strings
    //var descriptionPattern = RegExp(r'Passo \d+: {(.*?)}');
    /*
    var descriptionPattern = RegExp(r'(Passo \d+: {.*?})');
    print("DESCRIPTION PATTERN: $descriptionPattern");
    var matches = descriptionPattern.allMatches(chatCompletion.choices[0].message.content);
    print("MATCHES: $matches");
    List<String> description = matches.map((match) => match.group(1)!.trim()).toList();
    */  

    /*
    var systemMessage = 
      """
      Você funcionará com um API de recomendação de produtos. Esse API se chama Xerxes v.1, e seu apelido é X1.
      Vou listar alguns produtos e você deverá perguntar se quero fazer alguma receita.
      e logo em seguida entregar uma lista de produtos que se relacionam com eles.Siga exatamente os exemplos.
      Exemplo 1: X1 Limão, Cachaça. Resposta: Você quer fazer uma caipirinha ? Gelo, Açúcar Mascavo, Morango, Maracujá
      Exemplo 2: X1 Leite, Farinha, Chocolate. Resposta: Você quer fazer um bolo de chocolate ? Fermento, Ovos, Açúcar, Chocolate em barras.
      Exemplo 3: X1 Feijão preto, Linguiça. Resposta: Você quer fazer uma feijoada? Arroz, Bacon, Paio, Couve mineira, Laranja, Pimenta.
      """;

    var userMessage = "X1 $productsStr";
    */

  /*Future<String> X1(List<String> products) async {
    var productsStr = products.join(', ');
    var systemMessage = 
      """
      Você funcionará com um API de recomendação de produtos. Esse API se chama Xerxes v.1, e seu apelido é X1.
      Vou listar alguns produtos e você deverá perguntar se quero fazer alguma receita.
      e logo em seguida entregar uma lista de produtos que se relacionam com eles.Siga exatamente os exemplos.
      Exemplo 1: X1 Limão, Cachaça. Resposta: Você quer fazer uma caipirinha ? Gelo, Açúcar Mascavo, Morango, Maracujá
      Exemplo 2: X1 Leite, Farinha, Chocolate. Resposta: Você quer fazer um bolo de chocolate ? Fermento, Ovos, Açúcar, Chocolate em barras.
      Exemplo 3: X1 Feijão preto, Linguiça. Resposta: Você quer fazer uma feijoada? Arroz, Bacon, Paio, Couve mineira, Laranja, Pimenta.
      """;

    var userMessage = "X1 $productsStr";

    var messages = [
      OpenAIChatCompletionChoiceMessageModel(
        content: systemMessage,
        role: OpenAIChatMessageRole.system,
      ),
      OpenAIChatCompletionChoiceMessageModel(
        content: userMessage,
        role: OpenAIChatMessageRole.user,
      ),
    ];

    var chatCompletion = await _aiService.createCompletion(
      model: "gpt-3.5-turbo",
      prompt: messages,
    );

    return chatCompletion.choices[0].messages.content;
  }*/

  // Continue with X1a, X2, X2a in the same manner

/*
class Xerxes {
  late AIService _aiService;


  // Função para criar a string de produtos
  String _createProductString(List<EanModel> produtos) {
    return produtos.map((produto) => produto.nome).join(", ");
  }

  Future<String> x1(List<EanModel> produtos) async {
    String produtosStr = _createProductString(produtos);
    String prompt = 
      """
      Você funcionará com um API de recomendação de produtos. Esse API se chama Xerxes v.1, e seu apelido é X1. 
      Vou listar alguns produtos e você deverá perguntar se quero fazer alguma receita.
      e logo em seguida entregar uma lista de produtos que se relacionam com eles.Siga exatamente os exemplos.
      Exemplo 1: X1 Limão, Cachaça. Resposta: Você quer fazer uma caipirinha ? Gelo, Açúcar Mascavo, Morango, Maracujá.
      Exemplo 2: X1 Leite, Farinha, Chocolate. Resposta: Você quer fazer um bolo de chocolate ? Fermento, Ovos, Açúcar, Chocolate em barras.
      Exemplo 3: X1 Feijão preto, Linguiça. Resposta: Você quer fazer uma feijoada? Arroz, Bacon, Paio, Couve mineira, Laranja, Pimenta.
      X1 $produtosStr.
      """;
    return await _aiService.generateText(prompt, 200);
  }

  // Funções X1a, X2, X2a seguem um padrão similar
}
*/
